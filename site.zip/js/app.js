head.load(
	"js/lib/jquery.min.js",
	"js/lib/idle-timer.min.js",
	"js/common.js"
);